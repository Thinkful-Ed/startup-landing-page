startup-landing-page
====================

This is the starting repository for the FEWD landing page clone - based on the Karma Page.

#### Instructions

There are two methods for downloading the contents of this repository:

##### Option 1 - Clone

1. Press the fork button in the top right of this repository
  - This will copy the repository into your own repository
2. Once you have your own version of the repository -- Clone the repository
  - This can be achieved in your computer's Command Line
  - `git clone <enter the repository url here>`
  - The above command will download the files into a new folder with the same name as your copy of the repository
  
##### Option 2 - Download the ZIP file

- TBA
